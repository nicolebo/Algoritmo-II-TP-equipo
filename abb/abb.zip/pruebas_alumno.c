#include "abb.h"
#include "pila.h"
#include "testing.h"
#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void pruebas_abb_alumno(){
    /*Ejecuta todas las pruebas*/

}